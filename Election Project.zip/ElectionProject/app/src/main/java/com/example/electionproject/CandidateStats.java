package com.example.electionproject;

class CandidateStats {

    public int hBoy1Votes = 0;
    public int hBoy2Votes = 0;
    public int hBoy3Votes = 0;

    private CandidateStats(){


    }
}
